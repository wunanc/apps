import SwiftUI
import SwiftData
import UniformTypeIdentifiers

struct ContentView: View {
    @Environment(\.modelContext) private var context
    // 添加排序规则，按 order 升序排列
    @Query(sort: \BigPool.order) private var bigPools: [BigPool]
    
    @State private var showingAddBigPool = false
    
    // 拖拽排序专用的本地状态，防止拖动时画面乱闪
    @State private var localPools: [BigPool] = []
    @State private var draggingPool: BigPool?
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    ForEach(localPools) { pool in
                        BigPoolCardView(bigPool: pool, localPools: $localPools)
                            // 长按拖拽配置
                            .onDrag {
                                self.draggingPool = pool
                                return NSItemProvider(object: pool.id.uuidString as NSString)
                            }
                            .onDrop(of: [.text], delegate: PoolDropDelegate(item: pool, localPools: $localPools, draggingItem: $draggingPool, context: context))
                    }
                }
                .padding()
            }
            .navigationTitle("余额池")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: { showingAddBigPool = true }) {
                        Image(systemName: "plus.rectangle.on.rectangle")
                    }
                }
            }
            .sheet(isPresented: $showingAddBigPool) {
                // 传过去的数量用于设置排序的最后一位
                AddBigPoolView(currentCount: bigPools.count)
            }
        }
        // 初始化和同步本地数组
        .onAppear { localPools = bigPools }
        .onChange(of: bigPools) { _, newValue in
            if draggingPool == nil { localPools = newValue }
        }
    }
}

// MARK: - 大池子卡片
struct BigPoolCardView: View {
    @Environment(\.modelContext) private var context
    @Bindable var bigPool: BigPool
    @Binding var localPools: [BigPool]
    
    @State private var showingAddSmallPool = false
    @State private var newSmallPoolName = ""
    @State private var showingEditColor = false
    
    // 修改大池名称相关状态
    @State private var showingRenameAlert = false
    @State private var newBigPoolName = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            // Header 部分
            HStack {
                // 将标题变为可点击的菜单
                Menu {
                    Button(action: { showingEditColor = true }) {
                        Label("修改主题色", systemImage: "paintpalette")
                    }
                    // 新增：修改池名按钮
                    Button {
                        newBigPoolName = bigPool.name
                        showingRenameAlert = true
                    } label: {
                        Label("修改池名", systemImage: "pencil")
                    }
                    Button(role: .destructive, action: deleteBigPool) {
                        Label("删除大池", systemImage: "trash")
                    }
                } label: {
                    HStack(spacing: 5) {
                        Text(bigPool.name).font(.title2).bold()
                        Image(systemName: "chevron.down.circle.fill")
                            .font(.caption).opacity(0.8)
                    }
                }
                
                Spacer()
                Text("总额: \(bigPool.totalBalance, format: .currency(code: "CNY"))")
                    .font(.headline)
            }
            .foregroundColor(.white)
            
            Divider().background(.white.opacity(0.5))
            
            // 小池子列表
            ForEach(bigPool.smallPools) { smallPool in
                NavigationLink(destination: SmallPoolDetailView(smallPool: smallPool)) {
                    HStack {
                        Text(smallPool.name).foregroundColor(.white)
                        Spacer()
                        Text("\(smallPool.currentBalance, format: .currency(code: "CNY"))")
                            .foregroundColor(.white)
                        Image(systemName: "chevron.right")
                            .foregroundColor(.white.opacity(0.7)).font(.caption)
                    }
                    .padding(.vertical, 8).padding(.horizontal, 12)
                    .background(Color.white.opacity(0.2)).cornerRadius(8)
                }
            }
            
            Button(action: { showingAddSmallPool = true }) {
                HStack {
                    Image(systemName: "plus.circle.fill")
                    Text("新建小池")
                }
                .font(.footnote).foregroundColor(.white).padding(.top, 5)
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(LinearGradient(colors: [Color(hex: bigPool.hexColor), Color(hex: bigPool.hexColor).opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing))
                .shadow(radius: 5)
        )
        // 新建小池子弹窗
        .alert("新建小池", isPresented: $showingAddSmallPool) {
            TextField("小池名称", text: $newSmallPoolName)
            Button("取消", role: .cancel) { newSmallPoolName = "" }
            Button("创建") {
                let newSmallPool = SmallPool(name: newSmallPoolName)
                bigPool.smallPools.append(newSmallPool)
                newSmallPoolName = ""
            }
        }
        // 修改颜色的弹窗
        .sheet(isPresented: $showingEditColor) {
            EditBigPoolColorView(bigPool: bigPool)
        }
        // 新增：修改大池名称的弹窗
        .alert("修改池名", isPresented: $showingRenameAlert) {
            TextField("新名称", text: $newBigPoolName)
            Button("取消", role: .cancel) { }
            Button("确定") {
                let trimmed = newBigPoolName.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty {
                    bigPool.name = trimmed
                }
            }
        } message: {
            Text("给大池起个新名字吧")
        }
    }
    
    private func deleteBigPool() {
        if let index = localPools.firstIndex(of: bigPool) {
            localPools.remove(at: index)
        }
        context.delete(bigPool)
        try? context.save()
    }
}
// MARK: - 新建大池子视图 (支持选色)
struct AddBigPoolView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    var currentCount: Int
    
    @State private var name = ""
    @State private var selectedColor = Color.blue
    
    var body: some View {
        NavigationStack {
            Form {
                TextField("大池名称 (如: 微信余额)", text: $name)
                ColorPicker("选择主题色", selection: $selectedColor, supportsOpacity: false)
            }
            .navigationTitle("新建大池")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("创建") {
                        let newPool = BigPool(name: name, hexColor: selectedColor.toHex(), order: currentCount)
                        context.insert(newPool)
                        dismiss()
                    }
                    .disabled(name.isEmpty)
                }
            }
        }
    }
}

// MARK: - 修改现有池子颜色视图
struct EditBigPoolColorView: View {
    @Environment(\.dismiss) private var dismiss
    @Bindable var bigPool: BigPool
    @State private var selectedColor: Color
    
    init(bigPool: BigPool) {
        self.bigPool = bigPool
        _selectedColor = State(initialValue: Color(hex: bigPool.hexColor))
    }
    
    var body: some View {
        NavigationStack {
            Form {
                ColorPicker("选择新主题色", selection: $selectedColor, supportsOpacity: false)
            }
            .navigationTitle("修改颜色")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        bigPool.hexColor = selectedColor.toHex()
                        dismiss()
                    }
                }
            }
        }
        // 固定弹窗的高度
        .presentationDetents([.height(200)])
    }
}

// MARK: - 拖拽排序逻辑委托
struct PoolDropDelegate: DropDelegate {
    let item: BigPool
    @Binding var localPools: [BigPool]
    @Binding var draggingItem: BigPool?
    var context: ModelContext
    
    func dropEntered(info: DropInfo) {
        guard let draggingItem = draggingItem, draggingItem != item else { return }
        guard let from = localPools.firstIndex(of: draggingItem),
              let to = localPools.firstIndex(of: item) else { return }
        
        if from != to {
            withAnimation(.default) {
                let movedItem = localPools.remove(at: from)
                localPools.insert(movedItem, at: to)
            }
        }
    }
    
    func dropUpdated(info: DropInfo) -> DropProposal? {
        return DropProposal(operation: .move)
    }
    
    func performDrop(info: DropInfo) -> Bool {
        // 放下时，将新的排序存入数据库
        for (index, pool) in localPools.enumerated() {
            pool.order = index
        }
        try? context.save()
        draggingItem = nil
        return true
    }
}
