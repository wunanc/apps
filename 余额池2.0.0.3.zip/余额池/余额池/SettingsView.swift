import SwiftUI

struct SettingsView: View {
    
    // 获取 App 版本号及构建号
    private var appVersion: String {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"
        return "\(version).\(build)"
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("设置页面")
                        // 以后可以在这里添加更多设置项
                } footer: {
                    HStack {
                        Spacer()
                        Text("版本号: \(appVersion)")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                        Spacer()
                    }
                    .padding(.vertical)
                }
            }
            .navigationTitle("设置")
        }
    }
}
