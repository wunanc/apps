//
//  Models.swift
//  余额池
//
//  Created by JCDesign on 2026/6/17.
//

import Foundation
import SwiftData
import SwiftUI
import UIKit // 用于颜色转换

@Model
final class BigPool {
    var id: UUID = UUID() // 用于拖拽时的唯一标识
    var name: String = ""             // 👈 加上 = ""
    var directBalance: Double = 0.0   // 👈 加上 = 0.0
    var hexColor: String = "007AFF"   // 👈 直接在这里赋默认值，告诉数据库旧数据默认用蓝色
    var order: Int = 0                // 👈 加上 = 0
    
    @Relationship(deleteRule: .cascade, inverse: \SmallPool.bigPool)
    var smallPools: [SmallPool] = []
    
    init(name: String, directBalance: Double = 0.0, hexColor: String = "007AFF", order: Int = 0) {
        self.name = name
        self.directBalance = directBalance
        self.hexColor = hexColor
        self.order = order
    }
    
    @Transient var totalBalance: Double {
        let smallPoolsTotal = smallPools.reduce(0) { $0 + $1.currentBalance }
        return directBalance + smallPoolsTotal
    }
}

@Model
final class SmallPool {
    var name: String
    var bigPool: BigPool?
    
    @Relationship(deleteRule: .cascade, inverse: \TransactionRecord.smallPool)
    var transactions: [TransactionRecord] = []
    
    init(name: String) {
        self.name = name
    }
    
    @Transient var currentBalance: Double {
        transactions.reduce(0) { $0 + $1.amount }
    }
}

@Model
final class TransactionRecord {
    var amount: Double
    var reason: String
    var date: Date
    var smallPool: SmallPool?
    
    init(amount: Double, reason: String, date: Date = .now) {
        self.amount = amount
        self.reason = reason
        self.date = date
    }
}

// MARK: - 颜色与十六进制互转工具
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (255, 0, 122, 255) // 默认蓝色
        }
        self.init(.sRGB, red: Double(r) / 255, green: Double(g) / 255, blue:  Double(b) / 255, opacity: Double(a) / 255)
    }

    func toHex() -> String {
        let uiColor = UIColor(self)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        uiColor.getRed(&r, green: &g, blue: &b, alpha: &a)
        let rgb: Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        return String(format: "%06x", rgb)
    }
}
