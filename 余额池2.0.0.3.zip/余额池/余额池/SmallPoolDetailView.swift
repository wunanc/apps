import SwiftUI
import SwiftData

struct SmallPoolDetailView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Bindable var smallPool: SmallPool
    
    @State private var activeSheet: TransactionType? = nil
    
    // 修改池名相关状态
    @State private var showingRenameAlert = false
    @State private var newName = ""
    
    enum TransactionType: Identifiable {
        case income, expense
        var id: TransactionType { self }
    }
    
    var body: some View {
        VStack {
            // 顶部余额展示
            VStack(spacing: 10) {
                Text("当前余额")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                Text("\(smallPool.currentBalance, format: .currency(code: "CNY"))")
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .foregroundColor(smallPool.currentBalance >= 0 ? .primary : .red)
            }
            .padding(.vertical, 30)
            
            // 加减按钮
            HStack(spacing: 40) {
                Button {
                    activeSheet = .expense
                } label: {
                    VStack {
                        Image(systemName: "minus.circle.fill")
                            .font(.largeTitle)
                            .foregroundColor(.red)
                        Text("扣减")
                    }
                }
                
                Button {
                    activeSheet = .income
                } label: {
                    VStack {
                        Image(systemName: "plus.circle.fill")
                            .font(.largeTitle)
                            .foregroundColor(.green)
                        Text("增加")
                    }
                }
            }
            .padding(.bottom, 20)
            
            Divider()
            
            // 历史明细记录
            List {
                Section(header: Text("历史明细")) {
                    ForEach(smallPool.transactions.sorted(by: { $0.date > $1.date })) { record in
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(record.reason)
                                    .font(.body)
                                Text(record.date, style: .date)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                            Text("\(record.amount > 0 ? "+" : "")\(record.amount, format: .currency(code: "CNY"))")
                                .font(.headline)
                                .foregroundColor(record.amount >= 0 ? .green : .red)
                        }
                    }
                    .onDelete(perform: deleteTransaction)
                }
            }
            .listStyle(.plain)
        }
        .navigationTitle(smallPool.name)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    // 新增：修改池名
                    Button {
                        newName = smallPool.name       // 预填当前名称
                        showingRenameAlert = true
                    } label: {
                        Label("修改池名", systemImage: "pencil")
                    }
                    
                    // 原有的删除按钮
                    Button(role: .destructive) {
                        deleteThisSmallPool()
                    } label: {
                        Label("删除此小池", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                        .font(.title3)
                }
            }
        }
        .sheet(item: $activeSheet) { sheetType in
            AddTransactionView(smallPool: smallPool, type: sheetType)
        }
        // 修改名称的弹窗
        .alert("修改池名", isPresented: $showingRenameAlert) {
            TextField("新名称", text: $newName)
            Button("取消", role: .cancel) { }
            Button("确定") {
                let trimmed = newName.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty {
                    smallPool.name = trimmed
                }
            }
        } message: {
            Text("给小池起个新名字吧")
        }
    }
    
    // 删除单个交易记录
    private func deleteTransaction(offsets: IndexSet) {
        let sorted = smallPool.transactions.sorted(by: { $0.date > $1.date })
        for index in offsets {
            context.delete(sorted[index])
        }
    }
    
    // 删除整个小池子
    private func deleteThisSmallPool() {
        context.delete(smallPool)
        dismiss()
    }
}
