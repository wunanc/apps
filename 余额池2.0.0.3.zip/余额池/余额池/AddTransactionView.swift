//
//  AddTransactionView.swift
//  余额池
//
//  Created by JCDesign on 2026/6/17.
//

import SwiftUI
import SwiftData

struct AddTransactionView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    
    var smallPool: SmallPool
    var type: SmallPoolDetailView.TransactionType
    
    @State private var amountString: String = ""
    @State private var reason: String = ""
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text(type == .income ? "增加金额" : "扣减金额")) {
                    TextField("输入金额", text: $amountString)
                        .keyboardType(.decimalPad)
                        .foregroundColor(type == .income ? .green : .red)
                    
                    TextField("输入变动理由 (例如: 喝奶茶)", text: $reason)
                }
            }
            .navigationTitle(type == .income ? "增加资金" : "记录支出")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { saveTransaction() }
                        .disabled(amountString.isEmpty || reason.isEmpty)
                }
            }
        }
    }
    
    private func saveTransaction() {
        guard let amount = Double(amountString) else { return }
        let finalAmount = type == .income ? amount : -amount
        let newRecord = TransactionRecord(amount: finalAmount, reason: reason)
        smallPool.transactions.append(newRecord)
        dismiss()
    }
}
