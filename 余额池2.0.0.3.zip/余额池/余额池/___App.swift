//___FILEHEADER___

import SwiftUI
import SwiftData

@main
struct 余额池App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: [BigPool.self, SmallPool.self, TransactionRecord.self])
    }
}
